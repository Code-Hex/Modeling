//
//  ViewController.swift
//  Switch
//
//  Created by CodeHex on 2015/10/16.
//  Copyright © 2015年 CodeHex. All rights reserved.
//

import UIKit
import AVFoundation

/* See https://gist.github.com/Code-Hex/b41c0bbb97ba2b8667d4
extension UIImage {
    func CropImageOfRect(rect: CGRect) -> UIImage {
        let drawpoint : CGPoint = CGPointMake(rect.origin.x, rect.origin.y)
        drawAtPoint(drawpoint)
        UIGraphicsBeginImageContextWithOptions(rect.size, false, UIScreen.mainScreen().scale)
        let croppedImage : UIImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return croppedImage
    }
}
*/

class ViewController: UIViewController, AVAudioPlayerDelegate, UIPickerViewDelegate, UIPickerViewDataSource {

    @IBOutlet weak var picker: UIPickerView!
    var Button : UIButton = UIButton()
    var time  = 0.2
    var player : AVAudioPlayer = try! AVAudioPlayer(contentsOfURL: NSURL(string: NSBundle.mainBundle().pathForResource("iwill", ofType: "wav")!)!)
    
    let sounds : Dictionary <String, String> = ["iwill" : "wav", "airhorn" : "mp3", "coin" : "wav"]
    var keys : [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        /* https://gist.github.com/Code-Hex/b41c0bbb97ba2b8667d4
        let Buttonimg : UIImage = UIImage(contentsOfFile: NSBundle.mainBundle().pathForResource("button", ofType: "png")!)!
        let first_rect : CGRect = CGRectMake(1, 1, 100, Buttonimg.size.height)
        let Push : UIImage = Buttonimg.CropImageOfRect(first_rect)
        let last_rect : CGRect = CGRectMake(Buttonimg.size.width / 2, 0, Buttonimg.size.width / 2, Buttonimg.size.height)
        let Pushing : UIImage = Buttonimg.CropImageOfRect(last_rect)
        */
        let Push : UIImage = UIImage(contentsOfFile: NSBundle.mainBundle().pathForResource("btn1", ofType: "png")!)!
        let Pushing : UIImage = UIImage(contentsOfFile: NSBundle.mainBundle().pathForResource("btn2", ofType: "png")!)!
        Button.frame.size = CGSizeMake(220, 220)
        Button.layer.position = CGPoint(x: self.view.frame.width / 2, y: self.view.frame.height / 2)
        self.view.addSubview(Button)
        self.view.backgroundColor = UIColor.whiteColor()
        player.delegate = self
        
        keys = Array(sounds.keys)
        // Button.layer.cornerRadius = 100
        Button.addTarget(self, action: Selector("play:"), forControlEvents: .TouchUpInside)
        Button.setImage(Push, forState: .Normal)
        Button.setImage(Pushing, forState: .Highlighted)
        picker?.delegate = self
        picker?.dataSource = self
        
        player.currentTime = time
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func play(gestureRecognizer: UITapGestureRecognizer) {
        if player.playing == true {
            player.stop()
            player.currentTime = time
            player.play()
        } else {
            player.play()
        }
        
    }
    
    func audioPlayerDidFinishPlaying(player: AVAudioPlayer, successfully flag: Bool) {
        print("Finish")
        self.view.backgroundColor = UIColor.whiteColor()
    }
    
    func loadsound(name: String, type: String) {
        let filepath : String = NSBundle.mainBundle().pathForResource(name, ofType: type)!
        let file : NSURL = NSURL(fileURLWithPath: filepath)
        player = try! AVAudioPlayer(contentsOfURL: file)
        time = name == "iwill" ? 0.2 : 0
    }
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return keys.count
    }

    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return keys[row]
    }
    
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        loadsound(keys[row], type: sounds[keys[row]]!)
    }
    
    override func prefersStatusBarHidden() -> Bool {
        return true
    }

}

